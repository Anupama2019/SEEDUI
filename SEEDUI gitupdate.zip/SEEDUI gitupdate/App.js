/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

 import DeviceSettingsScreen from './src/Screens/GroupActivity';
// import GroupDeviceSettingsScreen from './src/Screens/TestGroup.js';
 import UnpairedDevicesScreen from './src/Screens/UnpairedDevicesScreen';
 import HomeScreen from './src/Screens/HomeScreen';
 import FindDevicesScreen from './src/Screens/FindDevicesScreen.js';
// import BluetoothScreen from './src/Screens/BluetoothScreen.js';
 import SplashScreen from './src/Screens/SplashScreen.js';
 import ListComponent from './src/Components/ListComponent';
// //import AsyncScreen from './src/Screens/AsyncScreen';
// import SettingsScreen from './src/Screens/SettingsScreen';
// import LoginModal from './src/Screens/LoginModal';
 //import SampleView from './src/Screens/SampleView';

import React from 'react';
import {  createAppContainer} from 'react-navigation';
import { createMaterialTopTabNavigator } from "react-navigation-tabs";
import { createStackNavigator } from 'react-navigation-stack';

import { View, Text} from 'react-native';

const TabScreen = createMaterialTopTabNavigator(
  {
    'Nearby': { screen: HomeScreen, },
    'Out of range': { screen: HomeScreen },
  },
  {
    tabBarPosition: 'top',
    fontFamily: 'OpenSans',
    swipeEnabled: false,
    backBehavior: "none",
    animationEnabled: true,
    tabBarOptions: {
      activeTintColor: '#1579bb',
      inactiveTintColor: '#757575',
      style: {
        backgroundColor: '#FFFFFF',
      },
      labelStyle: {
        textAlign: 'center',
      },
      indicatorStyle: {
        borderBottomColor: '#007aff',
        borderBottomWidth: 2,
      },
    },
  },

);



//making a StackNavigator to export as default
const AppContainer = createStackNavigator({
  SplashScreen: { screen: SplashScreen },
  TabScreen: {
    screen: TabScreen,

    navigationOptions: {
      headerLeft: null,
      headerStyle:
      {
        backgroundColor: '#0360a7',
        shadowOpacity: 0,
        elevation: 0,
      },
      headerTintColor: '#fff',
      headerTitle: ({ style, children: title }) => {
        return (
          <View style={{ width: '100%' }}>
            <Text
              style={{
                color: 'white',
                textAlign: 'center',
                fontWeight: '500',
                fontSize: 18,
                fontFamily: 'OpenSans',
                marginTop: 10
              }}>
              My Devices
          </Text>
            <Text
              style={{
                color: 'white',
                textAlign: 'center',
                fontWeight: "400",
                fontSize: 14,
                marginBottom: 15,
                fontFamily: 'OpenSans',
              }}>
              Previously paired Eaton devices
          </Text>
          </View>
        )
      },
    },

  },

  ListComponent: { screen: ListComponent },
   HomeScreen: { label: 'Home', screen: HomeScreen, },
   UnpairedDevicesScreen: { screen: UnpairedDevicesScreen },
   DeviceSettingsScreen: { screen: DeviceSettingsScreen },
   FindDevicesScreen: { screen: FindDevicesScreen },
//   GroupDeviceSettingsScreen: { screen: GroupDeviceSettingsScreen },
//   BluetoothScreen: { screen: BluetoothScreen },
//   //AsyncScreen: { screen: AsyncScreen },
//   SettingsScreen: { screen: SettingsScreen },
//  // SampleView: { screen: SampleView },
//   LoginModal: { screen: LoginModal },
  'Out of range': { screen: 'Out of range' }
});

console.log(this)

export default createAppContainer(AppContainer);

console.disableYellowBox = true;