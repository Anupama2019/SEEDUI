import React, { Component } from 'react';
import { View, Text } from 'react-native';
import { Left, Body, Right, Button, Icon, Card, CardItem, } from 'native-base';
import styles from '../Style.js';


export default renderCard = (props,data) => {


    let values = Object.values(data);


    return (values.map((item, contentIndex) => {
     
        let centries = Object.entries(item);

        return (centries.map((a, b) => {

            if ((a[0].toString()).includes("Group") == true) {
                return null
            }
            else {
                let arr = Object.entries(a[1]);
                return (
                    <Card style={styles.CardStyle} >
                        <CardItem header style={styles.CardBorder} >
                            <Left>
                                <Body>
                                    <Text style={styles.CardHeader} >{((a[0]).split(","))[0]}</Text>
                                </Body>
                            </Left>
                        </CardItem>
                        {(arr.map((c, d) => {
                            let entries = Object.values(c[1]);
                           
                            if ((c[0]).toString().includes("Group") == true) {
                                return (
                                    <CardItem button bordered style={styles.CardBorder} 
                                      onPress={()=>{props.navigation.navigate('GroupDeviceSettingsScreen', { ItemHolder: (c[1]) })}}
                                       >
                                        <Left>
                                            <Body>
                                                <Text style={styles.CardItem} >{((c[0]).split(","))[0]}</Text>
                                            </Body>
                                        </Left>
                                        {(entries.map((e, f) => {
                                            return (
                                                <Right >
                                                    <Body style={styles.CardBody}>
                                                        <View style={styles.CardView}>
                                                            <Icon style={styles.RightIcon} name="ios-arrow-forward" />
                                                        </View>
                                                    </Body>
                                                </Right>
                                            )
                                        }))}

                                    </CardItem>
                                )
                            }
                            else {
                                return (
                                    <CardItem button header style={styles.CardBorder} onPress={()=>{props.navigation.navigate('SettingsScreen')}} >
                                        <Left>
                                            <Body>
                                                <Text style={styles.CardItem} >{((c[0]).split(","))[0]}</Text>
                                            </Body>
                                        </Left>
                                        <Right >
                                            <Body style={styles.CardBody}>
                                                <View style={styles.CardView}>
                                                    <Text style={styles.CardItemRight}>{(c[1]).defaultValue} </Text>
                                                    <Icon style={styles.RightIcon} name="ios-arrow-forward" />
                                                </View>
                                            </Body>
                                        </Right>
                                    </CardItem>
                                )
                            }
                        }))}
                    </Card>
                )
            }
        }
        ))
    }))
};