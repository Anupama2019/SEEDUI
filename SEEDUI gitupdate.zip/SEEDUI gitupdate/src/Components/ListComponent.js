import React, { Component } from 'react';
import { View, Image, TouchableOpacity, SectionList, Platform, Linking, UIManager, LayoutAnimation, RefreshControl } from 'react-native';
import { Container, Content, Text } from 'native-base';
import fav_enable from '../../assets/Images/fav_enable3x.png';
import fav_disable from '../../assets/Images/fav_disable3x.png';
import styles from '../Style.js';
import { withNavigation } from 'react-navigation';

/********************************************************************************************************************************** 
   
    react-native-swipeable-row --
        Package for implementing the swipe left feature
        installation -- 
            npm i --save react-native-swipeable-row
        if one encounters theis error 
            "Error:Cause: unable to find valid certification path to requested target"
            Please refer first solution on this link  
                https://stackoverflow.com/questions/42415666/errorcause-unable-to-find-valid-certification-path-to-requested-target


**********************************************************************************************************************************/
import Swipeable from 'react-native-swipeable-row';




class ListComponent extends React.Component {

    static navigationOptions = ({ navigation }) => ({
        header: null,
    });

    constructor() {
        super();
        this.state = {
            expanded: false,
            show_fav_disable_Img: true,
            refreshing: false,
            data: "",
            Information: [

                {
                    TitleID: 'EATON_DEV_1',
                    TextID: '...A83BB9',
                    assetImageRight: require('../../assets/Images/location_icon3x.png'),
                    rssi: 3,
                }, {
                    TitleID: 'EATON_DEV_2',
                    TextID: '...A83BB9',
                    assetImageRight: require('../../assets/Images/location_icon3x.png'),
                    rssi: 3,
                }, {
                    TitleID: 'EATON_DEV_3',
                    TextID: '...A83BB9',
                    assetImageRight: require('../../assets/Images/location_icon3x.png'),
                    rssi: 3,
                }
            ]
        };
        if (Platform.OS == 'android') {
            UIManager.setLayoutAnimationEnabledExperimental(true);
        }
    }


    //deleteItemById() has Swipe left to delete functionality
    deleteItemById = TitleID => {
        const filteredData = this.state.Information.filter(item => item.TitleID !== TitleID);
        this.setState({ Information: filteredData });

    }

    // implements Pull to refresh Functionality
    _onRefresh = () => {
        this.setState({ refreshing: true });
        this.timeoutHandle = setTimeout(() => {

            this.setState({ refreshing: false })
        }, 5000);
    }

    // implements tap to expand feature for each row in ListComponent
    changeLayout = () => {
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        this.setState({ expanded: !this.state.expanded });
    }

    // implements the tap on Star to fav/unfav a device feature
    renderImage = () => {
        var imgSource = this.state.show_fav_disable_Img ? fav_disable : fav_enable;
        return (
            <Image
                style={{ width: 25, height: 25 }}
                source={imgSource}
            />
        );
    };

    // Renders the BLERange image according to the rssi value mentioned in the Information array
    renderBLERange() {
        if (this.state.Information.rssi == 0) {
            return (
                <View style={{ paddingLeft: 20, justifyContent: 'center' }}>
                    <Image style={{ width: 25, height: 25 }} source={require('../../assets/Images/BLERange0_3x.png')} />
                </View>
            );
        }
        if (this.state.Information.rssi == 1) {
            return (
                <View style={{ paddingLeft: 20, justifyContent: 'center' }}>
                    <Image style={{ width: 25, height: 25 }} source={require('../../assets/Images/BLERange1_3x.png')} />
                </View>
            );
        }
        if (this.state.Information.rssi == 2) {
            return (
                <View style={{ paddingLeft: 20, justifyContent: 'center' }}>
                    <Image style={{ width: 25, height: 25 }} source={require('../../assets/Images/BLERange2_3x.png')} />
                </View>
            );
        }
        else {
            return (
                <View style={{ paddingLeft: 20, justifyContent: 'center' }}>
                    <Image style={{ width: 25, height: 25 }} source={require('../../assets/Images/BLERange3_3x.png')} />
                </View>
            );
        }
    }

    /*  Implements the functionality of not showing Fav button (Star image) on UnpairedDevices Screen
        and then if its on HomeScreen then Toggles the image on click
        control goes to renderImage() function onPress()  */
    renderFavImage() {
        if (this.props.navigation.state.routeName == 'UnpairedDevicesScreen') {
            return null
        }
        else {
            return (
                <TouchableOpacity style={{ paddingLeft: 7, justifyContent: 'center' }}
                    onPress={() => this.setState({ show_fav_disable_Img: !this.state.show_fav_disable_Img })}>
                    {this.renderImage()}
                </TouchableOpacity>
            )
        }
    }

    render() {
        /*************************************************************
 
                If else condition for checking on which screen 
                is the list component being displayed, so as to 
                disable the swipe left to delete feature on the 
                UnpairedDevices screen

        *************************************************************/
        if (this.props.navigation.state.routeName == 'UnpairedDevicesScreen') {
            return (
                <Container >
                    <Content>

                         {/* SectionList-1 Starts */}
                        <SectionList
                            sections={[
                                { data: this.state.Information },
                            ]}
                            renderItem={({ item }) =>
                                //View-1 Starts
                                <View>
                                    <TouchableOpacity onPress={this.changeLayout}>
                                        {/* View-2 Starts */}
                                        <View style={styles.container}>

                                            {this.renderBLERange()}

                                            {this.renderFavImage()}

                                            {/* View-3 Starts */}
                                            <View style={{ justifyContent: 'center', alignItems: 'center', marginLeft: 20 }}>
                                                <Text style={styles.SectionListItems}>{item.TitleID}</Text>
                                                <Text style={{ fontSize: 13, color: 'grey', paddingTop: 10, marginLeft: -15, fontFamily: 'OpenSans', }}>{item.TextID}</Text>
                                            </View>
                                            {/* View-3 Ends */}

                                            {/* View-4 Starts */}
                                            <View style={{ justifyContent: 'flex-end', alignItems: 'center', flex: 1, flexDirection: 'row', paddingRight: 10, }}>
                                                <TouchableOpacity onPress={() => this.props.navigation.navigate('FindDevicesScreen', { Information: (this.state.Information) })}>
                                                    <Image style={{ width: 25, height: 25 }} source={item.assetImageRight} />
                                                </TouchableOpacity>
                                            </View>
                                            {/* View-4 Ends */}

                                        </View>
                                        {/* View-2 Ends */}

                                    </TouchableOpacity>
                                    {/* View-5 Starts */}
                                    < View style={{ marginLeft: 80, height: this.state.expanded ? null : 0, overflow: 'hidden', fontSize: 18, fontFamily: 'OpenSans' }}>

                                        {/* View-6 Starts */}
                                        <View style={{ flexDirection: 'row', marginBottom: 10 }}>
                                            <Text style={styles.ExpandableTextGray}> ServiceUUID: </Text>
                                            <Text style={styles.ExpandableTextBlack}> 0xOptional("FEAA")</Text>
                                        </View>
                                        {/* View-6 Ends */}

                                        <Text style={styles.ExpandableTextBlue} > Eddystone URL:</Text>
                                        <Text style={styles.ExpandableTextBlack} > Frame Type: url</Text>
                                        <Text style={styles.ExpandableTextBlack}> Tx Power at 0m: 252dBm</Text>

                                        {/* View-7 Starts */}
                                        <View style={styles.CardView}>
                                            <Text style={styles.ExpandableTextBlack} > URL:</Text>
                                            <TouchableOpacity onPress={() => Linking.openURL('https://Eaton.com')}>
                                                <Text style={styles.ExpandableTextBlue} > https://Eaton.com</Text>
                                            </TouchableOpacity>
                                        </View>
                                        {/* View-7 Ends */}

                                    </ View>
                                    {/* View-5 Ends */}

                                    {/* View-8 Starts */}
                                    <View style={{ marginTop: 10, borderBottomWidth: 1, borderBottomColor: '#cecece', }} />
                                    {/* View-8 Ends */}


                                </View>
                                // View-1 Ends 

                            }

                            keyExtractor={(item, index) => index}
                            refreshControl={
                                /* refresh Control tag starts 
                                   import {RefreshControl} from 'react-native'
                                */
                                <RefreshControl
                                    refreshing={this.state.refreshing}
                                    onRefresh={this._onRefresh}
                                />
                                //RefreshControl Tag Ends
                            }
                        />
                        {/* SectionList 1 Ends */}

                    </Content>
                </Container>
            );
        }
        else {
            return (
                <Container >
                    <Content>

                        {/* SectionList 2 Starts */}
                        <SectionList
                            sections={[
                                { data: this.state.Information },
                            ]}

                            renderItem={({ item }) =>


                                /*************************************************************

                                    <Swipable> Tag used for implementing the Swipe feature 
                                    ends on line number -- 354
                                   
                                *************************************************************/
                                <Swipeable
                                    rightButtons={[
                                        // View-9 Starts 
                                        <View style={{ backgroundColor: "#0360a7", height: "100%" }}>
                                            <TouchableOpacity style={{
                                                flex: 1,
                                                justifyContent: 'center',
                                                paddingHorizontal: 15
                                            }} onPress={() => this.deleteItemById(item.TitleID)}
                                            >
                                                <Text style={{ color: "white", fontFamily: "OpenSans-Semibold" }}>
                                                    Delete
                                                </Text>
                                            </TouchableOpacity>

                                        </View>
                                        // View-9 Ends 

                                    ]}
                                >
                                {/* End of <Swipable> Start tag   */}

                                     {/* View-10 Starts */}
                                    <View>
                                        <TouchableOpacity onPress={this.changeLayout}>
                                            {/* View-11 Starts */}
                                            <View style={styles.container}>

                                                {this.renderBLERange()}

                                                {this.renderFavImage()}

                                                {/* View-12 Starts */}
                                                <View style={{ justifyContent: 'center', alignItems: 'center', marginLeft: 20 }}>
                                                    <Text style={styles.SectionListItems}>{item.TitleID}</Text>
                                                    <Text style={{ fontSize: 13, color: 'grey', paddingTop: 10, marginLeft: -15, fontFamily: 'OpenSans', }}>{item.TextID}</Text>
                                                </View>
                                                {/* View-12 Ends */}


                                                {/* View-13 Starts */}
                                                <View style={{ justifyContent: 'flex-end', alignItems: 'center', flex: 1, flexDirection: 'row', paddingRight: 10, }}>
                                                    <TouchableOpacity onPress={() => this.props.navigation.navigate('FindDevicesScreen', { Information: (this.state.Information) })}>
                                                        <Image style={{ width: 25, height: 25 }} source={item.assetImageRight} />
                                                    </TouchableOpacity>
                                                </View>
                                                {/* View-12 Ends */}


                                                {/* View-13 Starts */}


                                            </View>
                                            {/* View-11 Ends */}


                                        </TouchableOpacity>
                                        {/* View-14 Starts */}
                                        < View style={{ marginLeft: 80, height: this.state.expanded ? null : 0, overflow: 'hidden', fontSize: 18, fontFamily: 'OpenSans' }}>

                                             {/* View-15 Starts */}
                                            <View style={{ flexDirection: 'row', marginBottom: 10 }}>
                                                <Text style={styles.ExpandableTextGray}> ServiceUUID: </Text>
                                                <Text style={styles.ExpandableTextBlack}> 0xOptional("FEAA")</Text>
                                            </View>
                                             {/* View-15 Ends */}

                                            <Text style={styles.ExpandableTextBlue} > Eddystone URL:</Text>
                                            <Text style={styles.ExpandableTextBlack} > Frame Type: url</Text>
                                            <Text style={styles.ExpandableTextBlack}> Tx Power at 0m: 252dBm</Text>

                                             {/* View-16 Starts */}
                                            <View style={styles.CardView}>
                                                <Text style={styles.ExpandableTextBlack} > URL:</Text>
                                                <TouchableOpacity onPress={() => Linking.openURL('https://Eaton.com')}>
                                                    <Text style={styles.ExpandableTextBlue} > https://Eaton.com</Text>
                                                </TouchableOpacity>
                                            </View>
                                             {/* View-16 Ends */}

                                        </ View>
                                         {/* View-14 Ends */}

                                         {/* View-17 Starts */}
                                        <View style={{ marginTop: 10, borderBottomWidth: 1, borderBottomColor: '#cecece', }} />
                                         {/* View-17 Ends */}

                                    </View>
                                    {/* View-10 Ends */}

                                </Swipeable>
                                //Swipeable Tag ends
                            }

                            keyExtractor={(item, index) => index}
                            refreshControl={
                                 /* refresh Control tag starts 
                                   import {RefreshControl} from 'react-native'
                                */
                                <RefreshControl
                                    refreshing={this.state.refreshing}
                                    onRefresh={this._onRefresh}
                                />
                                //RefreshControl Tag Ends
                            }
                        />
                         {/* SectionList 2 Ends */}

                    </Content>
                </Container>
            );
        }

    }
}

export default withNavigation(ListComponent)



