import { StyleSheet } from 'react-native';

export default StyleSheet.create({
    MainContainer: {

        backgroundColor: '#0360a7'

    },
    CardHeader: {

        fontFamily: "OpenSans-Bold",
        fontSize: 17,
        color:'black'

    },
    CardItem: {

        marginTop: 5,
        marginBottom: 5,
        fontFamily: "OpenSans",
        fontSize: 14,
        color:'black'

    },
    CardItemRight: {

        marginTop: 5,
        marginBottom: 5,
        fontFamily: "OpenSans",
        fontSize: 14,
        color:'black'

    },
    CardBorder: {

        borderRadius: 8

    },

    HomeScreenContainer: {

        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#FFFFFF'

    },

    TouchableOpacityStyle: {

        position: 'absolute',
        width: 50,
        height: 50,
        alignItems: 'center',
        justifyContent: 'center',
        right: 30,
        bottom: 30,

    },

    container: {

        flexDirection: 'row',
        height: 70,
        paddingTop: 10,
       
    },
    SectionListItems: {

        color: 'black',
        fontSize: 15,
        paddingLeft: 15,
        fontFamily: 'OpenSans',

    },
    item: {

        fontFamily: 'OpenSans',
        fontSize: 19,
        color: 'black',
        marginTop: 6,
        marginBottom: 6,
        marginLeft: 10,

    },
    SecondActivityContainer: {

        backgroundColor: '#FFFFFF',
        alignItems: 'flex-start',
        marginLeft: 15,

    },
    DailogContainer: {

        flexDirection: 'row',
        backgroundColor: '#696969',
        height: 65,
        marginBottom: 1

    },
    ListItem: {

        color: 'white',
        fontSize: 16,
        fontFamily: 'OpenSans',

    },
    CardStyle: {

         marginLeft: 8,
         marginRight:8,
         elevation :4,
         borderRadius: 8,
         borderColor: 'grey',
        // shadowColor: '#575757',
        // shadowOpacity: 0.7,
        // shadowRadius: 8,

    },
    CardBody: {

        alignSelf: 'flex-end'

    },
    RightIcon: {

        marginLeft: 10,
        fontSize: 20,
        color: 'grey',
        marginTop: 5,

    },
    CardView: {

        flexDirection: 'row'

    },
    ExpandableTextGray: {

        color: 'gray',
        fontSize: 16,
        fontFamily: 'OpenSans' 

    },
    ExpandableTextBlue: {

        color: '#238cff',
        fontSize: 16,
        fontFamily: 'OpenSans' 

    },
    ExpandableTextBlack: {

        color: 'black',
        fontSize: 16,
        fontFamily: 'OpenSans' 

    },
}) 