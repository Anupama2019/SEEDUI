/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React, { Component } from 'react';
import { Container, Header, Left, Body, Right, Button, Icon, Content } from 'native-base';
import { View, Image, ImageBackground, Text, TouchableOpacity, TouchableHighlight, TextInput, FlatList } from 'react-native';
import DailogUI from './DailogUI';
import Modal from "react-native-modal";
import styles from '../Style.js';
import renderCard from './../Components/renderCard'
import getData from './../Components/dataComponent'

/****************************************************************
 * 
 *   Package -- react-native-elements
 *           -- Cross Platform React Native UI Toolkit
 *        installation - npm install react-native-elements
 * 
 ****************************************************************/
import { Overlay } from 'react-native-elements';


export default class GroupActivity extends Component {


  constructor(props) {
    super(props);
    global.userRole = "Observer";
    this.state = {
      isVisible: false,
      isPickerModalVisible: false,
      isDailogModalVisible: false,
      isLoginModalVisible: false,
      user: "Observer",
      selectedItem: 1,
      isEditable: true,
    }

  }


  static navigationOptions = ({ navigation }) => {
    const { goBack } = navigation.navigate;
    return {
      header: null,
    };
  };

  testFunc = (user) => {
    global.userRole = user;
    this.setState({ isVisible: false })
  }

  changeUserfunc = () => {

    this.setState({ isEditable: !this.state.isEditable });
    //this.setState({ isPickerModalVisible: false })
  }

   /*******************************************************************************
      
          To toggle the state isVisible so that overlay is displayed when clicked     

   ********************************************************************************/
  ShowHideTextComponentView() {

    if (this.state.isVisible == true) {
      this.setState({ isVisible: false })
    }
    else {
      this.setState({ isVisible: true })
    }
  }

  toggleDailogModal = () => {
    this.setState({ isDailogModalVisible: !this.state.isDailogModalVisible });
  };

  togglePickerModal = () => {
    this.setState({ isPickerModalVisible: !this.state.isPickerModalVisible });
  };

  toggleLoginModal = () => {
    this.setState({ isLoginModalVisible: !this.state.isLoginModalVisible });
  };

  FunctionToOpenHomeScreen = () => {
    this.props.navigation.navigate('HomeScreen');
  };

  OpenSecondActivity(card) {
    this.props.navigation.navigate('New', { ItemHolder: card });
  };

  OpenGroupDeviceSettingsScreen(card) {
    this.props.navigation.navigate('GroupDeviceSettingsScreen', { ItemHolder: card });
  };

  updateUser = (user) => {
    this.setState({ user: user })
    // global.userRole = user;
    this.setState({ isPickerModalVisible: false })
    //this.props.togglePickerModal(this.state.user);
    //this.setState({ isPickerModalVisible: !this.state.isPickerModalVisible });
  }

  onItemSelected = selectedItem => {
    this.setState({ user: wheelPickerData[selectedItem] })
  }

  onPressButton = () => {
    this.setState({ isEditable: false })
  }

  render() {
    console.log(this.state.newUser);
    console.log(this.state.password);

    let x = getData("User", global.userRole)
    // console.log(x);
    return (

      <Container>
        <View style={{ height: "100%", width: "100%", backgroundColor: "transparent" }}>
          <Header style={styles.MainContainer}>
            <Left>

              <TouchableOpacity onPress={() => this.props.navigation.navigate('Out of range')}>
                <Image source={require('../../assets/Images/back3x.png')} style={{ width: 35, height: 35 }} />
              </TouchableOpacity>
            </Left>
            <Right>

              <Button transparent>
                <Image source={require('../../assets/Images/mail3x.png')} style={{ width: 25, height: 25 }} />
              </Button>

              <Modal isVisible={this.state.isDailogModalVisible}>
                <DailogUI toggleDailogModal={this.toggleDailogModal.bind(this)} />
              </Modal>

              <Button transparent onPress={() => this.toggleDailogModal()}>
                <Image source={require('../../assets/Images/info_icon3x.png')} style={{ width: 35, height: 35 }} />
              </Button>


            




              {/**************************************************************************
              
                        when clicked button it toggles the value of state isVisible 

              ***************************************************************************/}
              <Button transparent onPress={() => this.ShowHideTextComponentView()}>
                 <Image source={require('../../assets/Images/account_icon3x.png')} style={{ width: 35, height: 35 }} />
              </Button>

            </Right>
          </Header>

          <ImageBackground source={require('../../assets/Images/IMG_648413x.png')} style={{ width: '100%', height: 200 }}>

            <Image source={require('../../assets/Images/eaton_logo_white3x.png')} style={{ marginTop: 50, marginLeft: 130, width: 90, height: 80, resizeMode: 'contain' }} />
            <Text style={{ alignSelf: "flex-end", color: 'white', marginTop: -90, fontSize: 15, fontFamily: 'OpenSans', marginRight: 20 }}>{global.userRole}</Text>
            <Text style={{ marginLeft: 130, color: 'white', marginTop: 85, fontSize: 17, fontWeight: 'bold', fontFamily: 'OpenSans', }}>Device Short Desc</Text>
            <Text style={{ marginLeft: 130, color: 'white', marginTop: 3, fontSize: 16, fontWeight: '500', fontFamily: 'OpenSans', }}>Device Long Desc</Text>
            <Image source={require('../../assets/Images/fav_disable3x.png')} style={{ marginTop: -65, alignSelf: "flex-end", width: 60, height: 60, marginRight: 20 }} />
            <Image source={require('../../assets/Images/device_placeholder3x.png')} style={{ marginLeft: 35, marginTop: -95, marginBottom: 45, width: 80, height: 80 }} />


          </ImageBackground>



          <View style={{ height: "100%", width: "100%", backgroundColor: "transparent" }}>

              {/**************************************************************************
              
                  checks if the state isVisible is true or not 
                  Displays the Login Overlay if true

              ***************************************************************************/}
            {
              this.state.isVisible ?
                <Overlay
                  isVisible={this.state.isVisible}
                  // onBackdropPress={() => this.setState({ isVisible: false })}
                  width="auto"
                  height="auto"
                >
                  <View style={{ width: 250, height: 350 }}>
                    <Image source={require('../../assets/Images/account3x.png')} style={{ width: 40, height: 40, alignSelf: 'center', marginTop: 20, }} />
                    <Text style={{ alignSelf: 'center', color: '#0360a7', fontSize: 20, marginTop: 20, fontFamily: 'OpenSans', }}>Change Account </Text>

                    <View style={{
                      flexDirection: 'row',
                      borderBottomWidth: 2,
                      borderColor: '#0360a7',
                      marginHorizontal: 22,

                    }}>
                      <TextInput style={{ flex: 1, height: 40, fontSize: 18, marginTop: 30, fontFamily: 'OpenSans', paddingLeft: 6 }}
                        onChangeText={(newUser) => this.setState({ newUser })}
                        placeholderTextColor="#0360a7"
                        placeholder={this.state.user}
                        //value={this.state.password}
                        keyboardType={"none"}
                        editable={this.state.isEditable}
                        returnKeyType='go'
                        autoCorrect={false}
                        onFocus={this.togglePickerModal}
                      />
                      <Icon
                        type="Entypo"
                        name='chevron-up'
                        style={{ marginTop: 35, color: "#0360a7", fontSize: 25 }}
                      />

                    </View>

                    <View style={{
                      flexDirection: 'row',
                      borderBottomWidth: 2,
                      borderColor: '#0360a7',
                      marginHorizontal: 22
                    }}>
                      <TextInput style={{ flex: 1, height: 40, fontSize: 17, fontFamily: 'OpenSans', marginTop: 15, paddingLeft: 6 }}
                        onChangeText={(password) => this.setState({ password })}
                        placeholderTextColor="#696969"
                        placeholder={'Password'}
                        value={this.state.password}
                        secureTextEntry
                        returnKeyType='go'
                        autoCorrect={false}
                        selectionColor="#428AF8"
                      />
                    </View>

                    <View style={{ marginTop: 70 }}>
                      <View style={{ flexDirection: 'row', justifyContent: 'space-between', }}>
                        <TouchableHighlight onPress={() => this.setState({ isVisible: false })}>
                          <Text style={{ color: '#2E86D1', fontSize: 18, alignSelf: 'flex-start', marginLeft: 10, fontFamily: 'OpenSans', }}>
                            Cancel
                          </Text>
                        </TouchableHighlight>

                        <TouchableHighlight onPress={() => this.onPressButton()}>
                          <Text style={{ color: '#2E86D1', fontSize: 18, alignSelf: 'flex-start', marginLeft: 10, fontFamily: 'OpenSans', }}>
                            Change
                          </Text>
                        </TouchableHighlight>

                        <TouchableHighlight onPress={() => this.testFunc((this.state.user))}>
                          <Text style={{ color: '#2E86D1', fontSize: 18, alignSelf: 'flex-end', marginRight: 10, fontFamily: 'OpenSans', }}>Next</Text>
                        </TouchableHighlight>
                      </View>
                    </View>



                  </View>


                </Overlay> : null

            }
             {/**************************************************************************
              
                  checks if the state isPickerModalVisible is true or not 
                  Displays the Picker Overlay if true

              ***************************************************************************/}
            {
              this.state.isPickerModalVisible ?
                <Overlay
                  isVisible={this.state.isVisible}
                  // onBackdropPress={() => this.setState({ isPickerModalVisible: false })}
                  width={"100%"}
                  height={250}
                  overlayBackgroundColor="#d1d5db"
                  overlayStyle={{ marginTop: 405 }}
                >
                  <View style={{ height: "100%", width: "100%", backgroundColor: "#d1d5db" }}>
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', backgroundColor: '#d1d5db', }}>
                      <TouchableHighlight onPress={() => this.setState({ isPickerModalVisible: false }) & (this.setState({ user: "Operator" }))}>
                        <Text style={{ color: '#2E86D1', fontSize: 18, marginVertical: 10, alignSelf: 'flex-start', marginLeft: 10, fontFamily: 'OpenSans', }}>
                          Cancel
                        </Text>
                      </TouchableHighlight>
             
                      <TouchableHighlight onPress={() => this.setState({ isPickerModalVisible: false })}>
                        <Text style={{ color: '#2E86D1', fontSize: 18, marginTop: 10, alignSelf: 'flex-start', marginRight: 10, fontFamily: 'OpenSans', }}>
                          Done
                        </Text>
                      </TouchableHighlight>

                    </View>
                    <View style={{ backgroundColor: "#D3D3D3", width: "100%", height: "100%" }}>

                      <FlatList style={{ marginTop: 20 }}
                        data={[
                          { key: 'Observer' }, { key: 'Admin' }, { key: 'Engineer' }, { key: 'Operator' },]}

                        renderItem={({ item }) =>


                          <Text style={{ textAlign: "center", color: "black", fontFamily: "OpenSans", fontSize: 25 }} onPress={() => this.updateUser((item.key))}>
                            {item.key}
                          </Text>


                        }
                        ItemSeparatorComponent={this.renderSeparator}

                      />
                    </View>

                  </View>

                </Overlay>
                : null
            }
            < Content>
              {renderCard(this.props, x)}
            </Content>

          </View>

        </View>
      </Container>


    );
  }
}
