import React, { Component } from 'react';
import { View, Text, TouchableOpacity, Image, Platform, LayoutAnimation, UIManager, Linking } from 'react-native';
import { Container, Content } from 'native-base';
import styles from '../Style.js';
import ListComponent from './../Components/ListComponent'


export default class UnpairedDevicesScreen extends Component {
  static navigationOptions = ({ navigation }) => ({
    // headerLeft: null,
    header: null,
  });
  constructor() {
    super();
    this.state = { expanded: false };
    if (Platform.OS == 'android') {
      UIManager.setLayoutAnimationEnabledExperimental(true);
    }
  }

  changeLayout = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    this.setState({ expanded: !this.state.expanded });
  }

 

  render() {

    const { goBack } = this.props.navigation;
    return (
      <Container >
    

          <View >
            <View style={{ backgroundColor: '#0360a7' }}>
              <View style={{ marginTop: 30, backgroundColor: '#0360a7', height: 180, paddingBottom: 15 }}>

                <View style={{ paddingTop: 10, paddingLeft: 14 }}>
                  {/* <TouchableOpacity onPress={() => goBack()}> */}
                  <TouchableOpacity onPress={() => this.props.navigation.navigate('Out of range')}>
                 
                    <Image source={require('../../assets/Images/back3x.png')} style={{ width: 30, height: 30 }} />
                  </TouchableOpacity>
                </View>

                <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                  <Image source={require('../../assets/Images/bluetooth_icon3x.png')} style={{ width: 35, height: 35 }} />
                </View>

                <View style={{ justifyContent: 'center', alignSelf: 'center', paddingTop: 8 }}>
                  <Text style={{ color: '#DAD9DE', fontFamily: 'OpenSans', }}>Enable Pairing Mode</Text>
                </View>

                <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'space-between' }}>
                  <View style={{ justifyContent: 'center', alignSelf: 'center', paddingLeft: 60 }}>
                    <Image source={require('../../assets/Images/pair_device3x.png')} style={{ width: 35, height: 35 }} />
                  </View>

                  <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                    <Text style={{ color: '#DAD9DE', fontFamily: 'OpenSans', }}>- or -</Text>
                  </View>

                  <View style={{ justifyContent: 'center', alignSelf: 'center', paddingRight: 60 }}>
                    <Image source={require('../../assets/Images/ic_nfc_black_24px.png')} style={{ width: 35, height: 35 }} />
                  </View>
                </View>

              </View>
            </View>
            <View style={styles.SecondActivityContainer}>

              <Text style={{ marginLeft: 20, marginTop: 10, color: '#3693cb', fontSize: 19, fontWeight: '500', fontFamily: 'OpenSans', }}>AVAILABLE DEVICES </Text>
              <Text style={{ marginLeft: 19, color: '#3693cb', fontSize: 19, fontWeight: '400', fontFamily: 'OpenSans', }}>Tap to connect </Text>
            </View>
          </View>

          <ListComponent />
          
       
      </Container >

    );
  }
}


