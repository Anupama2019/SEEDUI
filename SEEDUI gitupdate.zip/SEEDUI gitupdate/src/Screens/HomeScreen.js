import React, { Component } from 'react';
import { View, Image, TouchableOpacity, } from 'react-native';
import { Container, Content, Text, } from 'native-base';
import fav_enable from '../../assets/Images/fav_enable3x.png';
import fav_disable from '../../assets/Images/fav_disable3x.png';
import styles from '../Style.js';
import ListComponent from './../Components/ListComponent'


export default class HomeScreen extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      show_fav_disable_Img: true,
      information: '.',
    };
  }
  getKey() {
    try {
      const value = AsyncStorage.getItem('@MySuperStore:key');
      this.setState({ information: value });
    } catch (error) {
      console.log("Error retrieving data" + error);
    }
  }


  renderSeparator = () => {
    return (
      <View
        style={{
          marginTop: 6,
          marginBottom: 6,
          // marginLeft:10,
          height: 1,
          width: "100%",
          backgroundColor: "#a3a3a3",
        }}
      />
    );
  };

  renderImage = () => {
    var imgSource = this.state.show_fav_disable_Img ? fav_disable : fav_enable;
    return (
      <Image
        style={{ width: 25, height: 25 }}
        source={imgSource}
      />
    );
  };


  FunctionToOpenUnpairedDevicesScreen = () => {
     this.props.navigation.navigate('UnpairedDevicesScreen');
    //this.props.navigation.navigate('SampleView');
  }




  render() {
    if (this.state.information == '') {
      return (
        <Container >
     
        <View style={styles.HomeScreenContainerContainer}>
          <Text style={{
            marginTop: 15,
            fontFamily: "OpenSans",
            fontSize: 18,
            color: '#757575',
            alignSelf: 'center',
          }}>
            No devices connected
          </Text>
          <TouchableOpacity activeOpacity={0.5} onPress={this.FunctionToOpenUnpairedDevicesScreen} style={{ alignSelf: "flex-end", marginTop: 420 }}>
            <Image source={require('../../assets/Images/FAB.png')} style={{ resizeMode: 'contain', width: 75, height: 75, }} />
          </TouchableOpacity>
        </View>
        </Container>
      );
    }

    else {
      return (
        <Container >
         
            <ListComponent /> 
      
          <View style={styles.HomeScreenContainerContainer}>
            <TouchableOpacity activeOpacity={0.5} onPress={this.FunctionToOpenUnpairedDevicesScreen} style={styles.TouchableOpacityStyle} >
              <Image source={require('../../assets/Images/FAB.png')} style={{ resizeMode: 'contain', width: 75, height: 75, }} />
            </TouchableOpacity>
          </View>
        </Container>
      );
    }
  }
}



