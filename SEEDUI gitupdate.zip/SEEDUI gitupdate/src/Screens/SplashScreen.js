import React, { Component } from 'react';
import { StyleSheet, View, Image, TouchableOpacity, SectionList, ImageBackground } from 'react-native';

export default class SplashScreen extends React.Component {
    static navigationOptions = ({ navigation }) => ({

        header: null,
    })
    componentDidMount(){

        this.timeoutHandle = setTimeout(()=>{
             this.props.navigation.navigate('TabScreen')
        }, 4000);
   }
   
   componentWillUnmount(){
        clearTimeout(this.timeoutHandle); 
   }
        render() {


            return (
              
                <View styles={{ backgroundColor: 'black', width: 100, height: 100 }}>
                    <ImageBackground source={require('../../assets/Images/LaunchScreen3x.png')} style={{ width: '100%', height: '100%' }}>
                        <View style={{}}>
                        </View>
                    </ImageBackground>
                </View>
                
            )
        }
    }