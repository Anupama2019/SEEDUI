import React, { Component } from "react";
import { StyleSheet, Text, View, SectionList, TouchableHighlight } from "react-native";
import styles from '../Style.js';
const customData = require('../Observer.json');

export default class ListUI extends Component {

    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        let data = customData["Device Details"];

        let values = Object.values(data);


        return (values.map((item, contentIndex) => {

            let centries = Object.entries(item);
            return (centries.map((a, b) => {
                let arr = Object.entries(a[1]);
                if ((a[0]).toString().includes("Assembly_0") == true) {

                    return (

                        <View  >
                            <View style={{ height: 60, alignItems: 'center', backgroundColor: 'black', flexDirection: 'row', }}>
                                <View>
                                    <Text style={{
                                        color: '#ffffff',
                                        fontSize: 18, paddingLeft: 8, fontFamily: 'OpenSans',
                                    }}>BLE Device</Text>
                                </View>

                                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', flex: 1 }}>
                                    <TouchableHighlight onPress={() => { this.props.toggleDailogModal(); }}>
                                        <Text style={{
                                            color: '#2E86D1',

                                            fontSize: 18, paddingRight: 8, fontFamily: 'OpenSans',
                                        }}>CLOSE</Text>
                                    </TouchableHighlight>
                                </View>

                            </View>
                            {(arr.map((c, d) => {
                                let entries = Object.values(c);
                                if ((entries[0]).toString().includes("Group") != true) {

                                    let eValues = Object.values(entries[1]);
                                    let eKeys = Object.keys(entries[1]);
                                    return (
                                        (eValues.map((e, f) => {
                                            if ((e.Role_name).toString() == "other_display") {
                                                return (
                                                    <View style={styles.DailogContainer}>

                                                        <View style={{ paddingLeft: 10, justifyContent: 'center', alignItems: 'center' }}>
                                                            <Text style={styles.ListItem}>{eKeys[f]}</Text>
                                                        </View>

                                                        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', flex: 1 }}>
                                                            <Text numberOfLines={1} style={{
                                                                paddingRight: 10, color: 'white', fontSize: 16,
                                                                fontFamily: 'OpenSans',
                                                            }}>{e.defaultValue}</Text>
                                                        </View>

                                                    </View>
                                                    // <CardItem style={{ backgroundColor: "#424242", height: 60, marginBottom: 1 }} >
                                                    //     <Body style={{ flexDirection: "row" }}>
                                                    //         <Text style={{
                                                    //             color: '#ffffff',
                                                    //             fontSize: 15,
                                                    //             paddingTop: 5,
                                                    //             fontFamily: 'OpenSans'
                                                    //         }} >{eKeys[f]}</Text>
                                                    //         <Text style={{

                                                    //             color: '#ffffff',
                                                    //             textAlign: "right",
                                                    //             paddingTop: 5,
                                                    //             fontSize: 15,
                                                    //             fontFamily: 'OpenSans-Light',
                                                    //         }}>{e.defaultValue}</Text>

                                                    //     </Body>
                                                    // </CardItem>

                                                )
                                            }
                                        }))
                                    )

                                }

                            }))}
                        </View>
                    )
                }
            }))



        }))
    }
}

