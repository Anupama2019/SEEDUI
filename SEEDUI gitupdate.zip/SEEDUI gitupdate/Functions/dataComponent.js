const TestData = require('../src/TestData.json')

export default getData = (userType,userRole) => {
  
    //console.log(TestData);
    let data = TestData[userType][userRole]
    //console.log(data);
    return data;
}
