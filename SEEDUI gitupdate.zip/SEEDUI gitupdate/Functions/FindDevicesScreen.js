import React, { Component } from 'react';
import { FlatList, View, TouchableOpacity, Image,Text } from 'react-native';
//import { Container, Content, Text, Icon } from 'native-base';
import styles from '../src/Style';
//mport AsyncStorage from '@react-native-community/async-storage';

export default class FindDevicesScreen extends Component {

  static navigationOptions = ({ navigation }) => {
    //  const Info = navigation.state.params.Information;
    const { params = {} } = navigation.state;
    //  stringifiedInfo = JSON.stringify(Info);
    return {
      title: navigation.getParam('Title', ''),
      headerStyle: {
        backgroundColor: navigation.getParam('BackgroundColor', '#0360a7'),
      },
      headerTintColor: navigation.getParam('HeaderTintColor', '#fff'),
      headerRight: (

        <TouchableOpacity onPress={() => {params.handleConnect()}}>
          <Text
            style={{
              color: 'white', fontWeight: '500', fontSize: 18, marginRight: 10, fontFamily: 'OpenSans', marginRight: 10
            }}>
            Connect
            </Text>
        </TouchableOpacity>
      ),
      headerLeft: (
        <TouchableOpacity onPress={() => navigation.navigate('Out of range')}>
          <Image source={require('../../assets/Images/back3x.png')} style={{ marginLeft: 5, width: 30, height: 30 }} />
        </TouchableOpacity>
      ),
    };
  };

  FunctionToOpenDeviceSetingsScreen = (userRole) => {
    //this.props.navigation.setParams({ userRole: 'observer'});
    this.props.navigation.navigate('DeviceSettingsScreen',{ userRole: "Observer" });
  };

//   componentDidMount() {
//     this.props.navigation.setParams({ handleConnect: this.FunctionToOpenDeviceSetingsScreen });
//     // this.props.navigation.setParams({ userRole: "Observer"});
//   }


  renderSeparator = () => {
    return (
      <View
        style={{
          marginTop: 6,
          marginBottom: 6,
          marginLeft: 10,
          height: 1,
          borderBottomWidth: 1,
          borderBottomColor: '#cecece',
        }}
      />
    );
  };

 


  render() {
    // const { goBack } = this.props.navigation;

    return (
      <View>
             <FlatList
            data={[
              { key: 'Find Device' }, { key: '' },]}

            renderItem={({ item }) =>
              <Text style={styles.item}>
                {item.key}
              </Text>
            }
            ItemSeparatorComponent={this.renderSeparator}

          />
       
       </View>
      );
  }
}
