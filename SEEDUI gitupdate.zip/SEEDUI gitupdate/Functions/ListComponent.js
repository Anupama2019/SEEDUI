import React, { Component } from 'react';
import { View, Image, TouchableOpacity, SectionList, Platform, Linking, UIManager, LayoutAnimation, RefreshControl, ScrollView, ActivityIndicator, FlatList } from 'react-native';

// contains image for representing Fav device(filled star)
import fav_enable from '../assets/Images/fav_enable3x.png';

// contains image for representing unFav device(unfilled star)
import fav_disable from '../assets/Images/fav_disable3x.png';


/********************************************************************************************************************************** 
   Packages--
        react-navigation --
            Package for implementing navigation
                installation -- 
                    npm install react-navigation

        @react-native-community/async-storage --
            Package for implementing an asynchronous, unencrypted, persistent, key-value storage system for React Native
                installation -- 
                    npm i @react-native-community/async-storage

        react-native-ble-manager --
            Package for enabling communication between a phone and Bluetooth Low Energy (BLE) peripherals.
                installation -- 
                    npm i --save react-native-ble-manager

        react-native-swipeable-row --
            Package for implementing the swipe left feature
                installation -- 
                    npm i --save react-native-swipeable-row

        native-base --
            Package for implementing essential cross-platform UI components for React Native
                installation -- 
                    npm i native-base

       
**********************************************************************************************************************************/
// import { withNavigation } from 'react-navigation';
// import AsyncStorage from '@react-native-community/async-storage';
 import BleManager from 'react-native-ble-manager';
// import Swipeable from 'react-native-swipeable-row';
//import { Container, Text } from 'native-base';



export default class ListComponent extends React.Component {

    static navigationOptions = ({ navigation }) => ({
        // headerLeft: null,
        header: null,
    });

    // Lifecycle methods
    constructor(props) {
        super(props);


        /***********************************************************************************************************
        
            expanded : refers to whether the list component is expanded or not
                        default value : false (Not in expanded state)
                        usage : changeLayout()

            show_fav_disable_Img : refers to whether Unfilled star image ( fav disabled ) is being displayed or not
                        default value : true (Unfilled star image will be displayed)
                        usage : updateInformationDetails(),renderImage()

            refreshing : refers to whether the page is being refreshed or not
                        default value : false ( Not refreshing when the app is loaded )
                        usage :  _onRefresh()

            Information : holds the Device information being passed to it
                        default value : deviceInformation ( taken from props)

        ***************************************************************************************************************/
        this.state = {
            expanded: false,
            show_fav_disable_Img: true,
            refreshing: false,
            Information: props.deviceInformation,

        };

        //For enabling setAnimation for Android
        if (Platform.OS == 'android') {
            UIManager.setLayoutAnimationEnabledExperimental(true);
        }
    }

    /********************************************************************
     
        This will execute if any changes are made in device property

    *********************************************************************/
    componentWillReceiveProps(props) {
        this.setState({ Information: props.deviceInformation });
    }


    /*********************************************************************** 
     
         Implements pull to refresh functionality by changing the value of 
         refreshing from false to true. After a timer of 5000 ms the value 
         of refreshing is again set to false.
 
     ***********************************************************************/
    _onRefresh = () => {
        this.setState({ refreshing: true });

        this.timeoutHandle = setTimeout(() => {

            //this.props.handleRefresh('test')

            this.setState({ refreshing: false })
        }, 5000);
    }

    /*******************************************************
    
        Displays the last 6 digits of Device's PeripheralID
        Replace the arrayObjects

    ********************************************************/
    replaceAt(array, index, value) {
        //ret stores the sliced data
        const ret = array.slice(0);
        ret[index] = value;
        return ret;
    }

    /*************************************************************
    
       Calculates the distance between central and peripheral 
       devices and stores it in ratio

    *************************************************************/
    getDistance = (rssi, txPower) => {
        if (rssi == 0) return -1;

        else {
            const ratio = rssi / txPower;
            return (
                (ratio < 1.0
                    ? Math.pow(ratio, 10)
                    : 0.89976 * Math.pow(ratio, 7.7095) + 0.111) / 1000
            );
        }

    }

 /*******************************************************
     
       Filter the device data array to remove duplicates
       and display the unique devices 
   
   ********************************************************/
  getUnique(arr, comp) {

    //contains only unique devices
    const unique = arr
        .map(e => e[comp])
        .map((e, i, final) => final.indexOf(e) === i && i)

        .filter(e => arr[e]).map(e => arr[e]);

    return unique;
}

    // changeLayout = () => {
    //     if (Platform.OS == 'android') {
    //         UIManager.setLayoutAnimationEnabledExperimental(true);
    //     }

    //     LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    //     this.setState({ expanded: !this.state.expanded });

    // }


    /*********************************************************************** 
     
       Enables the user to make a device as Favourite or Unfavourite
       by clicking the Star image.If the device is set as Fav , filled 
       star is displayed else an unfilled star is displayed
  
     ************************************************************************/
    renderImage = () => {

       // this.state.show_fav_disable_Img = deviceInfo.isFavourate

        var imgSource = this.state.show_fav_disable_Img ? fav_enable : fav_disable;
        return (
            <Image
                style={{ width: 25, height: 25 }}
                source={imgSource}
            />
        );
    };

    renderBLERange(rssiValue) {

        let rssiStrength = (parseFloat(rssiValue) + 128) / 256
        /*  If the rssiStrength is greater than or equal to 0 and less than equal to 0.30 
                     returns BLE Range 1 image */
        if (rssiStrength >= 0 && rssiStrength <= 0.30) {
            return (
                <View style={{ paddingLeft: 20, justifyContent: 'center' }}>
                    <Image style={{ width: 25, height: 25 }} source={require('../assets/Images/BLERange1_3x.png')} />
                </View>
            );
        }


        /*  If the rssiStrength is greater than or equal to 0.31 and less than equal to 0.61 
                   returns BLE Range 2 image */
        if (rssiStrength >= 0.31 && rssiStrength <= 0.601) {
            return (
                <View style={{ paddingLeft: 20, justifyContent: 'center' }}>
                    <Image style={{ width: 25, height: 25 }} source={require('../assets/Images/BLERange2_3x.png')} />
                </View>
            );
        }


        /*  If the rssiStrength is greater than or equal to 0.61 and less than equal to 1.0 
                   returns BLE Range 3 image */
        if (rssiStrength >= 0.61 && rssiStrength <= 1.0) {
            return (
                <View style={{ paddingLeft: 20, justifyContent: 'center' }}>
                    <Image style={{ width: 25, height: 25 }} source={require('../assets/Images/BLERange3_3x.png')} />
                </View>
            );
        }


        /* for rest other cases returns BLE Range 3 image */
        else {
            return (
                <View style={{ paddingLeft: 20, justifyContent: 'center' }}>
                    <Image style={{ width: 25, height: 25 }} source={require('../assets/Images/BLERange3_3x.png')} />
                </View>

            );
        }
    }

    render() {


        return (
            // Container 1 Starts 
            <View>

                {/* SectionList-1 Starts */}
                <SectionList



                    refreshControl={
                        /* refresh Control tag starts 
                        import {RefreshControl} from 'react-native'
                    */
                        <RefreshControl
                            refreshing={this.state.refreshing}
                            onRefresh={this._onRefresh}
                        />
                        //RefreshControl Tag Ends
                    }

                />
            </View>

        );

    }
}



// export default withNavigation(ListComponent)
