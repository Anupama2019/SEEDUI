import React from 'react';
import "react-native";
import dataComponent from '../Functions/dataComponent'
import renderer from 'react-test-renderer'
import { shallow } from 'enzyme';


import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });

const TestData = require('../src/TestData.json')

/************************************************************ 
 * 
 *      Test 1
 *          --Checks if the data Component renders correctly
 * 
 ************************************************************/
it('renders correctly', () => {

    renderer.create(<dataComponent />);

});

/***************************************************************
*
*       Test 2
*           -- Snapshot testing of dataComponent
*
***************************************************************/
describe('ListComponent', () => {
    describe('Rendering', () => {
        it('should match to snapshot', () => {
            const component = shallow(<dataComponent />)
            expect(component).toMatchSnapshot()
        });
    });
});

it('test the getdata function', () => {

    let datacomponent = renderer.create(<dataComponent />).getInstance();
    //console.log(getData("User","Admin"))
    expect(getData("User","Admin")).toBe(TestData["User"]["Admin"])
});
