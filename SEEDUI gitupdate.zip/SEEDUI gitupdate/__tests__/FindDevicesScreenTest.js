import React from 'react';
import {Text} from "react-native";
import FindDevicesScreen from '../Functions/FindDevicesScreen'
import renderer from 'react-test-renderer'
import { shallow } from 'enzyme';


import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { func } from 'prop-types';

Enzyme.configure({ adapter: new Adapter() });

/************************************************************ 
 * 
 *      Test 1
 *          --Checks if the data Component renders correctly
 * 
 ************************************************************/
it('renders correctly', () => {

    renderer.create(<FindDevicesScreen />);

});

/***************************************************************
*
*       Test 2
*           -- Snapshot testing of dataComponent
*
***************************************************************/
describe('FindDevicesScreen', () => {
    describe('Rendering', () => {
        it('should match to snapshot', () => {
            const component = shallow(<FindDevicesScreen />)
            expect(component).toMatchSnapshot()
        });
    });
});


// test('onPress', () => {
//     //const { params = {} } = navigation.state;

//     const testFunc = jest.fn()
//     const params = {
//         handleConnect: testFunc,
//     }
//     const component = shallow(
//         <FindDevicesScreen/>
//     )
//     let Listcomponent = renderer.create(<FindDevicesScreen />).getInstance();
//         Listcomponent

//     component.simulate('press')
//     expect(testFunc).toHaveBeenCalled()
// })

// describe("Button component", () => {
//     navigate()
//     const navigation = navigate(screen);
//     test("it shows the expected text when clicked (testing the wrong way!)", () => {
//         let component = renderer.create(<FindDevicesScreen />).getInstance();
//     component.FunctionToOpenDeviceSetingsScreen()
//       //const TouchableOpacity = testInstance.findByType("TouchableOpacity");
//       //console.log(component)
//     //   TouchableOpacity.props.onClick();
//     //   expect(TouchableOpacity.props.children).toBe("PROCEED TO CHECKOUT");
//     });
//   });


// test('test onPress functionality', () => {
//     const onPressEvent = jest.fn();
//     onPressEvent.mockReturnValue('Link on press invoked');
//     const wrapper = shallow(<FindDevicesScreen.navigationOptions onPress={ onPressEvent } text='CustomLink Component'/>);
//     wrapper.find(Text).first().props().onPress();
//     expect(onPressEvent.mock.calls.length).toBe(1);
// });


describe('a button', () => {
    it('should be present', () => {
        let tree = renderer.create(<FindDevicesScreen
                text={'Press me'}/>
            ).toJSON()
        console.log(tree.children)
    })
})