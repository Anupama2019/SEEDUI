/***********************************************************************************************
 * 
 *   -- install enzyme,enzyme-adapter-react-16 and react-dom
 *          npm i — save-dev enzyme enzyme-adapter-react-16 react-dom
 *          npm install --save-dev react-dom enzyme
 * 
 *   -- import Enzyme , renderer,Adapter,shallow
 *          import Enzyme from 'enzyme';
 *          import renderer from 'react-test-renderer';
 *          import { shallow } from 'enzyme';
 *          import Adapter from 'enzyme-adapter-react-16';
 * 
 *   -- configure a new adapter for enzyme
 *          Enzyme.configure({ adapter: new Adapter() });
 *          
 *   -- To run tests
 *          type command "npm test" in the appfolder
 * 
 *   -- To check coverage 
 *          type command npm test -- --coverage in appfolder
 * 
 ***********************************************************************************************/
import React from 'react';
import "react-native";
import ListComponent from '../Functions/ListComponent'
import renderer from 'react-test-renderer'
import { shallow } from 'enzyme';
import fav_enable from '../assets/Images/fav_enable3x.png';
import BLE1 from '../assets/Images/BLERange1_3x.png'
import BLE2 from '../assets/Images/BLERange2_3x.png'
import BLE3 from '../assets/Images/BLERange3_3x.png'
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
const TestData = require('../src/TestData.json')

Enzyme.configure({ adapter: new Adapter() });


/************************************************************ 
 * 
 *      Test 1
 *          --Checks if the List Component renders correctly
 * 
 ************************************************************/
it('renders correctly', () => {

    renderer.create(<ListComponent />);

});

/***************************************************************
*
*       Test 2
*           -- Snapshot testing of ListComponent
*
***************************************************************/
describe('ListComponent', () => {
    describe('Rendering', () => {
        it('should match to snapshot', () => {
            const component = shallow(<ListComponent />)
            expect(component).toMatchSnapshot()
        });
    });
});


/***************************************************************************************************
 * 
 *      Test 3
 *          -- Checks if the component receives props and is able to set the Information state 
 *                  as props.deviceInformation  
 * 
 ***************************************************************************************************/
it('test the componentWillReceiveProps function', () => {

    let Listcomponent = renderer.create(<ListComponent />).getInstance();
    props = TestData
    Listcomponent.componentWillReceiveProps(props);
    expect(Listcomponent.state.Information).toBe(props.deviceInformation)
});



/********************************************************************************************************
 * 
 *      Test 4  
 *          -- Checks if the value of refreshing(true/false) is reversed when the function is called 
 * 
 ********************************************************************************************************/
it('test the onRefresh Component', () => {
    let Listcomponent = renderer.create(<ListComponent />).getInstance();
    jest.useFakeTimers();
    //console.log(Listcomponent)
    Listcomponent._onRefresh();
    expect(Listcomponent.state.refreshing).toBe(true)

})


/********************************************************************************************************
 * 
 *      Test  5 
 *          -- Checks if the time(in ms) set for the timer is equal to time it is called for.
 *          -- Checks how many times the setTimout function is called
 *         
 ********************************************************************************************************/
it('test the onRefresh Component', () => {

    let Listcomponent = renderer.create(<ListComponent />).getInstance();
    jest.useFakeTimers();
    Listcomponent._onRefresh();
    expect(setTimeout).toHaveBeenCalledTimes(2);
    expect(setTimeout).toHaveBeenLastCalledWith(expect.any(Function), 5000);

})


/***************************************************************************************************
 * 
 *      Test 6
 *          -- Checks if the arr[] returned after slicing it at a particular index with value val
 *              matches with the expected array
 * 
 ****************************************************************************************************/
it('test the replaceAt Component', () => {
    let Listcomponent = renderer.create(<ListComponent />).getInstance();
    var array = [];

    actualOutput = (Listcomponent.replaceAt([1, 2, 3, 4], 2, 0))
    var actualJSON = JSON.stringify(array.concat(actualOutput));
    var expectedJSON = JSON.stringify([1, 2, 0, 4]);

    expect(actualJSON).toEqual(expectedJSON);
})


/***************************************************************************************************
 * 
 *      Test 7
 *          -- Checks if the function returns -1 when the rssi value is equal to zero 
 * 
 ****************************************************************************************************/
it('test the getDistance function', () => {

    let Listcomponent = renderer.create(<ListComponent />).getInstance();
    expect(Listcomponent.getDistance(0, 2)).toBe(-1);

});


/***************************************************************************************************
 * 
 *      Test 8
 *          -- Check if the function calculates the ratio by dividing rssi value with txPower
 *              when the rssi value is not eqaul to zero  
 * 
 ***************************************************************************************************/
it('test the getDistance function', () => {

    let Listcomponent = renderer.create(<ListComponent />).getInstance();
    expect(Listcomponent.getDistance(1, 2)).toBe(9.765625e-7);

});


// it('test the getUnique function', () => {


//     let Listcomponent = renderer.create(<ListComponent />).getInstance();

//     var array = [];
//     var actualJSON = JSON.stringify(array.concat(Listcomponent.getUnique([7, 7, 8, 9, 6], 1)));
//     var expectedJSON = JSON.stringify([7]);

//     expect(actualJSON).toBe(expectedJSON);

// });

/***************************************************************************************************
 * 
 *      Test 10
 *          -- Checks if in the renderImage function the value of the state show_fav_disable_Img
 *                  is true   
 * 
 ***************************************************************************************************/
it('test the renderImage function', () => {

    let Listcomponent = renderer.create(<ListComponent />).getInstance();
    Listcomponent.renderImage();
    expect(Listcomponent.state.show_fav_disable_Img).toBe(true)
});

/***************************************************************************************************
 * 
 *      Test 11
 *          -- Checks if in the renderImage function , the correct image (ie. fav_enable or 
 *                  fav_disable) is being rendered according to the value of the state 
 *                  show_fav_disable_Img provided to it
 * 
 ***************************************************************************************************/
it('test the renderImage function', () => {

    let Listcomponent = renderer.create(<ListComponent />).getInstance();
    Listcomponent.renderImage();
    expect(Listcomponent.renderImage().props.source).toBe(fav_enable)
    //expect(Listcomponent.renderImage()).toBe(fav_enable) 
});

/***************************************************************************************************
 * 
 *      Test 12
 *          -- Checks if in the renderBLERange function BLE1 image is rendered when boundary 
 *                  value of if condition number one is supplied ie rssi = -128  
 * 
 ***************************************************************************************************/
it('test the renderBLERange1 boundary(start) ', () => {

    let Listcomponent = renderer.create(<ListComponent />).getInstance();
    Listcomponent.renderBLERange(-128);
    expect(Listcomponent.renderBLERange(-128).props.children.props.source).toBe(BLE1)
   
});

/***************************************************************************************************
 * 
 *      Test 13
 *          -- Checks if in the renderBLERange function BLE1 image is rendered when boundary 
 *                  value of if condition number one is supplied ie rssi = -51.3 
 * 
 ***************************************************************************************************/
it('test the renderBLERange1 boundary(end)', () => {

    let Listcomponent = renderer.create(<ListComponent />).getInstance();
    Listcomponent.renderBLERange(-51.3);
    expect(Listcomponent.renderBLERange(-51.3).props.children.props.source).toBe(BLE1)
   
});

/***************************************************************************************************
 * 
 *      Test 14
 *          -- Checks if in the renderBLERange function BLE2 image is rendered when boundary 
 *                  value of if condition number two is supplied ie rssi = -48.64  
 * 
 ***************************************************************************************************/
it('test the renderBLERange2 boundary(start)', () => {

    let Listcomponent = renderer.create(<ListComponent />).getInstance();
    Listcomponent.renderBLERange(-48.64);
    expect(Listcomponent.renderBLERange(-48.64).props.children.props.source).toBe(BLE2)
   
});

/***************************************************************************************************
 * 
 *      Test 15
 *          -- Checks if in the renderBLERange function BLE2 image is rendered when a random 
 *                  value of if condition number two is supplied ie rssi = 0 
 * 
 ***************************************************************************************************/
it('test the renderBLERange2 ', () => {

    let Listcomponent = renderer.create(<ListComponent />).getInstance();
    Listcomponent.renderBLERange(0);
    expect(Listcomponent.renderBLERange(0).props.children.props.source).toBe(BLE2)
   
});

/***************************************************************************************************
 * 
 *      Test 16
 *          -- Checks if in the renderBLERange function BLE2 image is rendered when boundary 
 *                  value of if condition number two is supplied ie rssi = 25.856  
 * 
 ***************************************************************************************************/
it('test the renderBLERange2 boundary(end)', () => {

    let Listcomponent = renderer.create(<ListComponent />).getInstance();
    Listcomponent.renderBLERange(25.856);
    expect(Listcomponent.renderBLERange(25.856).props.children.props.source).toBe(BLE2)
   
});


/***************************************************************************************************
 * 
 *      Test 17
 *          -- Checks if in the renderBLERange function BLE3 image is rendered when boundary 
 *                  value of if condition number three is supplied ie rssi = 28.16 
 * 
 ***************************************************************************************************/
it('test the renderBLERange3 boundary(start)', () => {

    let Listcomponent = renderer.create(<ListComponent />).getInstance();
    Listcomponent.renderBLERange(28.16);
    expect(Listcomponent.renderBLERange(28.16).props.children.props.source).toBe(BLE3)
   
});


/***************************************************************************************************
 * 
 *      Test 18
 *          -- Checks if in the renderBLERange function BLE3 image is rendered when boundary 
 *                  value of if condition number three is supplied ie rssi = 128
 * 
 ***************************************************************************************************/
it('test the renderBLERange3 boundary(end)', () => {

    let Listcomponent = renderer.create(<ListComponent />).getInstance();
    Listcomponent.renderBLERange(128);
    expect(Listcomponent.renderBLERange(100).props.children.props.source).toBe(BLE3)
   
});

/***************************************************************************************************
 * 
 *      Test 19
 *          -- Checks if in the renderBLERange function BLE3 image is rendered when a random value 
 *                  of else condition is supplied ie rssi = 150
 * 
 ***************************************************************************************************/
it('test the renderBLERange else condition', () => {

    let Listcomponent = renderer.create(<ListComponent />).getInstance();
    Listcomponent.renderBLERange(150);
    expect(Listcomponent.renderBLERange(100).props.children.props.source).toBe(BLE3)
   
});







