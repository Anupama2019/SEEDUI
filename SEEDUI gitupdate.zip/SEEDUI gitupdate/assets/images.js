const images = {
    account:require('./assets/Images/Account.png'),
};

export default images;